package unicuritiba.db;

public class Pontuação {
	
	private int pontuacao;

	public Pontuação(String nome, String pontos) {
		// TODO Auto-generated constructor stub
	}

	public int getPontuacao() {
		return pontuacao;
	}

	public void setPontuacao(int pontuacao) {
		this.pontuacao = pontuacao;
	}

	public String getNome() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getPontos() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setId(int id) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
