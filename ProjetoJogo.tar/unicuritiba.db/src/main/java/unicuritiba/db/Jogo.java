package unicuritiba.db;

public class Jogo {
	
	private String nome;
	private String tema;
	private int pontMax;
	
	public Jogo(String nome2, String tema2) {
		// TODO Auto-generated constructor stub
	}
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTema() {
		return tema;
	}
	public void setTema(String tema) {
		this.tema = tema;
	}
	public int getPontMax() {
		return pontMax;
	}
	public void setPontMax(int pontMax) {
		this.pontMax = pontMax;
	}


	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}


	public void setId(int id) {
		// TODO Auto-generated method stub
		
	}


	


	
	
	
	}
